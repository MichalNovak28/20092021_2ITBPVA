import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class test1{


    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);


    System.out.println("vypln array 4 cisla");

        int ar1 = sc.nextInt();
        int ar2 = sc.nextInt();
        int ar3 = sc.nextInt();
        int ar4 = sc.nextInt();

    System.out.println("kolikrat probehne funkce?");
        
        int count = sc.nextInt();


        ArrayList<Integer> list = new ArrayList<>();

        list.add(ar1);
        list.add(ar2);
        list.add(ar3);
        list.add(ar4);

        System.out.println(list);
        

        for(int i = 0; i < count; i++){

            Collections.swap(list, 0, 3);

            System.out.println(list);

        }




    }




}