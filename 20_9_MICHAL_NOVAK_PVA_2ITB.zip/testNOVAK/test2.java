import java.util.ArrayList;
import java.util.Scanner;

public class test2{


public static void main(String[] args) {
    

    java.util.Scanner sc = new Scanner(System.in);
        ArrayList<Integer> list = new ArrayList<>();

        int sum = 0;

        System.out.println("vypln array 4 cisla");

        int ar1 = sc.nextInt();
        int ar2 = sc.nextInt();
        int ar3 = sc.nextInt();
        int ar4 = sc.nextInt();

        list.add(ar1);
        list.add(ar2);
        list.add(ar3);
        list.add(ar4);

        System.out.println(list);


        sum = list.get(0) + list.get(1) + list.get(2) + list.get(3);

}


}